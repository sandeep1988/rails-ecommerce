class Admin::DashboardController < Admin::BaseController

  def show
  end

end
